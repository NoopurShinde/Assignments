var fsBlocking = require("fs");

const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});


var filedata = fsBlocking.readFileSync('Demo.txt');

console.log("Blocking: "+filedata.toString());
console.log("Program Blocking Ended \n\n");

 
var fsNonBlocking = require("fs");


fsNonBlocking.readFile('Demo.txt', function (err, data) {
    if (err) return console.error("Error is:"+err);
    console.log("Non-blocking: "+filedata.toString());
 });
 
 console.log("Program nonblocking Ended");

 
